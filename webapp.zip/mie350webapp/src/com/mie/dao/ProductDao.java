package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;
import com.mie.util.*;

public class ProductDao {

	private Connection connection;

	public ProductDao() {
		connection = DbUtil.getConnection();
	}
	
	//add other methods for different filtering
	
	public List<Product> getProductByPrice(String price) {
		List<Product> products = new ArrayList<Product>();
		//Get product by price filter
		return products;
	}

	public List<Product> getProductFromSuggestedProducts() {
		List<Product> products = new ArrayList<Product>();
		//Get product from the suggested products form
		return products;
	}

	public List<Product> getProductByKeyword(String keyword) {
		List<Product> products = new ArrayList<Product>();
		try {
			//Change this statement
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from product where firstname LIKE ? OR lastname LIKE ? OR email LIKE ? OR dob LIKE ?");

			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProductid(rs.getInt("prodid"));
				//Add others
				products.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return products;
	}
}
